import { useState } from "react";
import axios from "axios";

function AddEmployee() {
  const [employee_code, setCode] = useState("");
  const [name, setName] = useState("");
  const [monthly_salary, setSalary] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/employees", {
        employee_code,
        name,
        monthly_salary
      });

      alert("Employee Added Successfully!");

      setCode("");
      setName("");
      setSalary("");

    } catch (err) {
      alert("Error adding employee");
    }
  };

  return (
    <div className="max-w-xl bg-gray-800 p-8 rounded-xl border border-gray-700 shadow-xl">
      <h1 className="text-3xl font-bold mb-6">Add Employee</h1>

      <form onSubmit={handleSubmit} className="space-y-4">

        <div>
          <label className="block mb-1">Employee Code</label>
          <input 
            type="text"
            value={employee_code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full p-3 bg-gray-700 rounded border border-gray-600"
            required
          />
        </div>

        <div>
          <label className="block mb-1">Name</label>
          <input 
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 bg-gray-700 rounded border border-gray-600"
            required
          />
        </div>

        <div>
          <label className="block mb-1">Monthly Salary</label>
          <input 
            type="number"
            value={monthly_salary}
            onChange={(e) => setSalary(e.target.value)}
            className="w-full p-3 bg-gray-700 rounded border border-gray-600"
            required
          />
        </div>

        <button 
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 p-3 rounded-lg text-white font-bold"
        >
          Add Employee
        </button>

      </form>
    </div>
  );
}

export default AddEmployee;
