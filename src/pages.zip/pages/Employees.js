import React, { useEffect, useState } from "react";
import axios from "axios";

function Employees() {
  const [employees, setEmployees] = useState([]);

  // Load employees
  const loadEmployees = async () => {
    try {
      const r = await axios.get("/employees");
      setEmployees(r.data);
    } catch (err) {
      alert("Failed to load employees!");
    }
  };

  // Delete employee
  const deleteEmployee = async (id) => {
    if (!window.confirm("Are you sure you want to delete this employee?")) return;

    try {
      const r = await axios.delete(`http://localhost:5000/api/employees/${id}`);
      alert("Employee deleted!");
      loadEmployees(); // refresh list
    } catch (err) {
      alert("Delete failed!");
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold mb-6">Employees</h1>

      <table className="w-full border border-gray-700 text-left">
        <thead>
          <tr className="bg-gray-800">
            <th className="p-3 border border-gray-700">ID</th>
            <th className="p-3 border border-gray-700">Code</th>
            <th className="p-3 border border-gray-700">Name</th>
            <th className="p-3 border border-gray-700">Salary</th>
            <th className="p-3 border border-gray-700">Actions</th>
          </tr>
        </thead>

        <tbody>
          {employees.map((e) => (
            <tr key={e.id} className="hover:bg-gray-700">
              <td className="p-3 border border-gray-700">{e.id}</td>
              <td className="p-3 border border-gray-700">{e.employee_code}</td>
              <td className="p-3 border border-gray-700">{e.name}</td>
              <td className="p-3 border border-gray-700">{e.monthly_salary}</td>

              <td className="p-3 border border-gray-700">
                <a
                  href={`/employee/${e.id}`}
                  className="text-blue-400 underline mr-4"
                >
                  View
                </a>

                <button
                  onClick={() => deleteEmployee(e.id)}
                  className="bg-red-600 px-3 py-1 rounded hover:bg-red-700"
                >
                  Delete
                </button>
              </td>

            </tr>
          ))}
        </tbody>

      </table>
    </div>
  );
}

export default Employees;
