import React, { useEffect, useState } from "react";
import axios from "axios";

function OffDay() {
  const [employees, setEmployees] = useState([]);
  const [employee_id, setEmployeeId] = useState("");
  const [off_date, setOffDate] = useState("");
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);

  // Load employees when page opens
  useEffect(() => {
    axios
      .get("http://localhost:5000/api/employees")
      .then((res) => setEmployees(res.data))
      .catch(() => alert("Error loading employees"));
  }, []);

  const submitOffDay = async () => {
    if (!employee_id || !off_date) {
      alert("Employee & Off Date required!");
      return;
    }

    setLoading(true);

    try {
      await axios.post("/off-days", {
        employee_id,
        off_date,
        reason
     });

      alert("Off Day Added Successfully ✔");

      // Reset form
      setEmployeeId("");
      setOffDate("");
      setReason("");

    } catch (err) {
      console.log(err);
      alert("Failed to add off day ❌ (backend error)");
    }

    setLoading(false);
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6 text-white">Add Off Day</h1>

      <div className="bg-gray-800 p-6 rounded-xl shadow-lg max-w-xl">

        {/* EMPLOYEE DROPDOWN */}
        <label className="block text-gray-300 mb-2">Select Employee</label>
        <select
          value={employee_id}
          onChange={(e) => setEmployeeId(e.target.value)}
          className="w-full p-3 rounded bg-gray-700 text-white mb-4 outline-none"
        >
          <option value="">-- Choose Employee --</option>
          {employees.map((emp) => (
            <option key={emp.id} value={emp.id}>
              {emp.employee_code} — {emp.name}
            </option>
          ))}
        </select>

        {/* OFF DATE */}
        <label className="block text-gray-300 mb-2">Off Date</label>
        <input
          type="date"
          value={off_date}
          onChange={(e) => setOffDate(e.target.value)}
          className="w-full p-3 rounded bg-gray-700 text-white mb-4 outline-none"
        />

        {/* REASON */}
        <label className="block text-gray-300 mb-2">Reason (Optional)</label>
        <input
          type="text"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Eg: Sick Leave"
          className="w-full p-3 rounded bg-gray-700 text-white mb-4 outline-none"
        />

        {/* BUTTON */}
        <button
          onClick={submitOffDay}
          disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-700 p-3 rounded text-white font-semibold"
        >
          {loading ? "Saving..." : "Add Off Day"}
        </button>
      </div>
    </div>
  );
}

export default OffDay;
