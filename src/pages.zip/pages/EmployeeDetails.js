import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

function EmployeeDetails() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // load details inside useEffect to avoid lint missing-deps warning
    const load = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/employees/${id}/details`);
        setData(res.data);
      } catch (err) {
        console.error(err);
        alert("Failed to load employee details");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  if (loading) return <div className="text-gray-800 p-10">Loading...</div>;
  if (!data || !data.employee) return <div className="text-gray-800 p-10">No data found.</div>;

  const emp = data.employee;
  const offRecords = data.off_records || [];
  const advances = data.advances || [];

  // --- WEEK RANGE (today and previous 5 days = total 6 working days? we use last 7 days range here)
  const today = new Date();
  const weekEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate()); // midnight today
  const start = new Date(weekEnd);
  start.setDate(start.getDate() - 6); // last 7 days including today
  const weekStart = start;

  // helper to compare dates (YYYY-MM-DD)
  const dateKey = (d) => {
    const x = new Date(d);
    // return date string in YYYY-MM-DD for easy compare
    return x.toISOString().slice(0, 10);
  };

  const ws = weekStart.toISOString().slice(0, 10);
  const we = weekEnd.toISOString().slice(0, 10);

  // count off days in this week
  const offThisWeek = offRecords.filter((o) => {
    const od = o.off_date || o.off_date; // backend may send string
    const k = dateKey(od);
    return k >= ws && k <= we;
  });

  // advances in this week (sum amounts)
  const advThisWeek = advances.filter((a) => {
    const dt = a.date_taken || a.date_taken;
    const k = dateKey(dt);
    return k >= ws && k <= we;
  });

  const totalAdvance = advThisWeek.reduce((s, a) => s + (parseInt(a.amount, 10) || 0), 0);

  // Salary math: daily rate based on 26 working days (as your earlier logic)
  const monthly = Number(emp.monthly_salary) || 0;
  const workingDaysInMonth = 26;
  const dailyRate = Math.round(monthly / workingDaysInMonth);

  // As earlier you assumed a 6-day work week (Mon-Sat) — for weekly slip we calculate days present:
  // We'll use 6 working days by default as earlier code used 6.
  const weekWorkingDays = 6;
  const offCount = offThisWeek.length;
  const daysPresent = Math.max(0, weekWorkingDays - offCount);

  const grossForWeek = dailyRate * daysPresent;
  const netForWeek = grossForWeek - totalAdvance;

  // Print function: hide non-print via .no-print in CSS
  const handlePrint = () => {
    window.print();
  };

  return (
    // outer container - only .print-area will be printed (controlled by CSS below)
    <div className="p-8 text-gray-900">
      {/* header area (non-printable) */}
      <div className="no-print mb-6 flex justify-between items-center">
        <div className="text-sm text-gray-600">Payroll System</div>
        <div className="text-sm text-gray-600">Employee ID: {emp.id}</div>
      </div>

      {/* print-area: this will be the white slip printed */}
      <div className="print-area mx-auto max-w-3xl bg-white rounded shadow-lg p-8">
        {/* logo centered */}
        <div className="flex justify-center mb-4">
          {/* logo file put in public folder (public/bmw.jpg or bmw.png) */}
          <img src="/bmw.jpg" alt="logo" className="h-20 object-contain" />
        </div>

        <h2 className="text-2xl font-bold text-center mb-6">Employee Salary Slip</h2>

        {/* Basic info */}
        <div className="bg-white border border-gray-200 rounded p-4 mb-4 shadow-sm">
          <h3 className="font-semibold mb-2">Basic Information</h3>
          <p><strong>Name:</strong> {emp.name}</p>
          <p><strong>Code:</strong> {emp.employee_code}</p>
          <p><strong>Salary:</strong> Rs {monthly}</p>
        </div>

        {/* Off days */}
        <div className="bg-white border border-gray-200 rounded p-4 mb-4 shadow-sm">
          <h3 className="font-semibold mb-2">Off Days</h3>
          {offThisWeek.length === 0 ? (
            <p>No off-days this week ({ws} → {we}).</p>
          ) : (
            offThisWeek.map((o) => (
              <div key={o.id} className="mb-1">
                {dateKey(o.off_date)} — {o.reason || "No reason"}
              </div>
            ))
          )}
        </div>

        {/* Advances */}
        <div className="bg-white border border-gray-200 rounded p-4 mb-4 shadow-sm">
          <h3 className="font-semibold mb-2">Advances (This week)</h3>
          {advThisWeek.length === 0 ? (
            <p>No advances this week ({ws} → {we}).</p>
          ) : (
            advThisWeek.map((a) => (
              <div key={a.id} className="mb-1">
                {dateKey(a.date_taken)} — Rs {a.amount} ({a.note || "No note"})
              </div>
            ))
          )}
        </div>

        {/* Weekly Income Summary */}
        <div className="bg-white border border-gray-200 rounded p-4 shadow-sm">
          <h3 className="font-semibold mb-2">Weekly Income Summary ({ws} → {we})</h3>
          <p><strong>Daily Rate:</strong> Rs {dailyRate}</p>
          <p><strong>Week Working Days:</strong> {weekWorkingDays}</p>
          <p><strong>Off Days (this week):</strong> {offCount}</p>
          <p><strong>Days Present:</strong> {daysPresent}</p>
          <p><strong>Gross This Week:</strong> Rs {grossForWeek}</p>
          <p><strong>Total Advance (this week):</strong> Rs {totalAdvance}</p>
          <p className="text-xl font-bold mt-3">Net Pay (This Week): Rs {netForWeek}</p>
        </div>

        {/* bottom print info */}
        <div className="text-sm text-gray-500 mt-6">
          <div>Generated: {new Date().toLocaleString()}</div>
          <div className="text-xs mt-1">Note: Weekly calculation uses {workingDaysInMonth} working days/month & {weekWorkingDays}-day week for pro-rata.</div>
        </div>
      </div>

      {/* actions (no-print) */}
      <div className="no-print mt-6 flex gap-3">
        <button onClick={handlePrint} className="bg-blue-600 text-white px-4 py-2 rounded">Print Salary Slip</button>
      </div>
    </div>
  );
}

export default EmployeeDetails;
