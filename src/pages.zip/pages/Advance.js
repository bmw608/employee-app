import { useEffect, useState } from "react";
import axios from "axios";

function Advance() {
  const [employees, setEmployees] = useState([]);
  const [employeeId, setEmployeeId] = useState("");
  const [amount, setAmount] = useState("");
  const [dateTaken, setDateTaken] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  // Load Employees
  useEffect(() => {
    loadEmployees();
  }, []);

  async function loadEmployees() {
    try {
      const res = await axios.get("/employees");
      setEmployees(res.data);
    } catch (err) {
      alert("Error loading employees");
    }
  }

  // Submit Advance
  async function submitAdvance() {
    if (!employeeId || !amount || !dateTaken) {
      alert("Please fill all required fields");
      return;
    }

    setLoading(true);

    try {
      await axios.post("/advances", {
  employee_id: employeeId,
  amount,
  date_taken: dateTaken,
  note,
});

      alert("Advance Added Successfully");
      setEmployeeId("");
      setAmount("");
      setDateTaken("");
      setNote("");
    } catch (err) {
      alert("Error adding advance");
    }

    setLoading(false);
  }

  return (
    <div className="text-white p-8">
      <h1 className="text-3xl font-bold mb-6">Add Advance</h1>

      <div className="bg-gray-800 p-6 rounded-lg max-w-xl">

        {/* Employee Dropdown */}
        <label className="block mb-2 font-semibold">Select Employee</label>
        <select
          className="w-full p-3 rounded bg-gray-700 mb-4"
          value={employeeId}
          onChange={(e) => setEmployeeId(e.target.value)}
        >
          <option value="">-- Choose Employee --</option>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.employee_code} - {e.name}
            </option>
          ))}
        </select>

        {/* Amount */}
        <label className="block mb-2 font-semibold">Advance Amount</label>
        <input
          type="number"
          value={amount}
          className="w-full p-3 rounded bg-gray-700 mb-4"
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter amount"
        />

        {/* Date Taken */}
        <label className="block mb-2 font-semibold">Date</label>
        <input
          type="date"
          value={dateTaken}
          className="w-full p-3 rounded bg-gray-700 mb-4"
          onChange={(e) => setDateTaken(e.target.value)}
        />

        {/* Note */}
        <label className="block mb-2 font-semibold">Note (Optional)</label>
        <input
          type="text"
          value={note}
          className="w-full p-3 rounded bg-gray-700 mb-4"
          onChange={(e) => setNote(e.target.value)}
          placeholder="Eg: Emergency, Personal need"
        />

        {/* Button */}
        <button
          onClick={submitAdvance}
          disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-700 p-3 rounded text-white font-bold"
        >
          {loading ? "Saving..." : "Add Advance"}
        </button>
      </div>
    </div>
  );
}

export default Advance;
