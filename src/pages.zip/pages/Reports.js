import React, { useEffect, useState } from "react";
import axios from "axios";

function Reports() {
  const [lastReport, setLastReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const API = "http://localhost:5000";

  // LOAD LAST SAVED REPORT
  const loadLastReport = async () => {
    try {
      const r = await axios.get(`${API}/api/reports/last`);
      setLastReport(r.data);
    } catch (err) {
      console.error(err);
      alert("Failed to load report");
    }
  };

  useEffect(() => {
    loadLastReport();
  }, []);

  // GENERATE REPORT BUTTON
  const generateReport = async () => {
    const week_start = prompt("Enter Week Start (YYYY-MM-DD):");
    const week_end = prompt("Enter Week End (YYYY-MM-DD):");

    if (!week_start || !week_end) return;

    setLoading(true);

    try {
      await axios.post(`${API}/api/reports/generate-weekly`, {
        week_start,
        week_end,
      });

      alert("Weekly report generated successfully!");
      loadLastReport();
    } catch (err) {
      console.error(err);
      alert("Error generating report");
    }

    setLoading(false);
  };

  return (
    <div className="p-6 text-white">
      <h2 className="text-3xl font-bold mb-4">Weekly Reports</h2>

      <button
        onClick={generateReport}
        className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white mb-6"
      >
        {loading ? "Generating..." : "Generate Weekly Report"}
      </button>

      {/* LAST REPORT DISPLAY */}
      {lastReport ? (
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="text-xl font-bold mb-2">
            Last Generated Report: {lastReport.week_start} → {lastReport.week_end}
          </h3>

          <table className="w-full mt-4 text-left text-gray-200">
            <thead>
              <tr className="border-b border-gray-600">
                <th className="py-2">Code</th>
                <th>Name</th>
                <th>Present</th>
                <th>Off</th>
                <th>Advance</th>
                <th>Net Salary</th>
              </tr>
            </thead>
            <tbody>
              {lastReport.data.map((row, i) => (
                <tr key={i} className="border-b border-gray-700">
                  <td className="py-2">{row.employee_code}</td>
                  <td>{row.name}</td>
                  <td>{row.days_present}</td>
                  <td>{row.off_days}</td>
                  <td>{row.total_advance}</td>
                  <td>{row.net}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>No report generated yet.</p>
      )}
    </div>
  );
}

export default Reports;
