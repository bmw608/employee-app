import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [summary, setSummary] = useState({
    totalEmployees: 0,
    weeklyOff: 0,
    weeklyAdvances: 0,
  });

  useEffect(() => {
    loadDashboard();
  }, []);

const loadDashboard = async () => {
  try {
    const res = await axios.get("/dashboard-summary");


    setSummary({
      totalEmployees: res.data.total_employees,
      weeklyOff: res.data.week_off_days,
      weeklyAdvances: res.data.week_advances,
    });

  } catch (err) {
    alert("Failed to load dashboard data");
  }
};


  return (
    <div className="p-10 text-white">
      <h1 className="text-4xl font-bold mb-10">Dashboard</h1>

      <div className="grid grid-cols-3 gap-6">
        {/* Total Employees */}
        <div className="bg-gray-800 p-6 rounded-xl">
          <p className="text-lg">Total Employees</p>
          <p className="text-4xl font-bold">{summary.totalEmployees}</p>
        </div>

        {/* Weekly Off Days */}
        <div className="bg-gray-800 p-6 rounded-xl">
          <p className="text-lg">This Week Off Days</p>
          <p className="text-4xl font-bold">{summary.weeklyOff}</p>
        </div>

        {/* Weekly Advances */}
        <div className="bg-gray-800 p-6 rounded-xl">
          <p className="text-lg">This Week Advances</p>
          <p className="text-4xl font-bold">Rs {summary.weeklyAdvances}</p>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
